.. healpy.projector:

.. currentmodule:: healpy.projector

:mod:`projector` -- Spherical projections
=========================================

Basic classes
-------------
.. autosummary::
   :toctree: generated/

   SphericalProj
   GnomonicProj
   MollweideProj
   CartesianProj
