.. healpy.visufunc:

.. currentmodule:: healpy.zoomtool


:mod:`zoomtool` -- Interactive visualisation
================================

Interactive map visualization
-----------------------------
.. autosummary::
   :toctree: generated/

   mollzoom
